package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import Model.PacienteInsert;

public class PacienteDAOAtualizar {
    public static List<PacienteInsert> list() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private Connection con;
    private PreparedStatement cmd;
    
    public PacienteDAOAtualizar(){
        this.con = Conexao.Conectar();
    }
    
    public int atualizar (PacienteInsert p){
        try{
            String sql = "update paciente set nome=?, peso=?, altura=? where id=?;";
            
            cmd = con.prepareStatement(sql);
            cmd.setString(1, p.getNome());
            cmd.setFloat(2, p.getPeso());
            cmd.setFloat(3, p.getAltura());
            cmd.setInt(4, p.getId());
            
            if (cmd.executeUpdate() > 0){
                return p.getId();
        }
            else{
                return -1;
            }
        }
        catch (Exception e){
            System.out.println("ERRO: " + e.getMessage());
            return -1;
        }
        finally{
            Conexao.Desconectar(con);
        }
    }
    
    public List<PacienteInsert> listar(){
        try{
            String sql = "select * from paciente order by id";
            cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            
            List<PacienteInsert> lista = new ArrayList<>();
            while(rs.next()){
                
                PacienteInsert p = new PacienteInsert();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso"));
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p);
            }
            return lista;
        }
        catch (Exception e){
            System.out.println("ERRO: " + e.getMessage());
            return null;
        }   
        finally{
            Conexao.Desconectar(con);
        }
            
    }
    
    public List<PacienteInsert> pesquisarPorNome(String nome){
        try{
            String sql = "select * from paciente where nome like ? order by nome;";
            cmd = con.prepareStatement(sql);
            cmd.setString(1, "%" + nome + "%");
            
            ResultSet rs = cmd.executeQuery();
            List<PacienteInsert> lista = new ArrayList<>();
            
            while(rs.next()){
                PacienteInsert p = new PacienteInsert();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso")); 
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p);
            }
            return lista;
        }
        catch (Exception e){
            System.out.println("ERRO: " + e.getMessage());
            return null;
        }
        finally{
            Conexao.Desconectar(con);
        }
    }
}

