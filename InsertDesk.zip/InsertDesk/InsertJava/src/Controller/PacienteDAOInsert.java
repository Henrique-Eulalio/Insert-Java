package Controller;

import Model.PacienteInsert;
import java.sql.*;
import java.util.*;
//import model.PacienteInsert;

public class PacienteDAOInsert {
    
     public static List<PacienteInsert> list() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    //Abrindo nossa conexão com Banco de Dados
    private Connection con;
    private PreparedStatement cmd;
     
    public PacienteDAOInsert(){
        this.con = Conexao.Conectar();
    }
    
    public int inserir(PacienteInsert p){
           try{
            String sql = "insert into paciente (nome, peso, altura) values (?, ?, ?);";
            
            cmd = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            cmd.setString(1, p.getNome());
            cmd.setFloat(2, p.getPeso());
            cmd.setFloat(3, p.getAltura());
            
                        if (cmd.executeUpdate() > 0){
                            ResultSet rs = cmd.getGeneratedKeys();
                            return (rs.next()) ? rs.getInt(1): -1;
                        }else{
                            return -1;
                        }
        }        
        catch (SQLException e){
            System.out.println("ERRO SQL: " + e.getMessage());
            return -1;
        }  
        finally{
            Conexao.Desconectar(con);
        }     
    }
    
    public int atualizar (PacienteInsert p){
        try{
            String sql = "update paciente set nome=?, peso=?, altura=? where id=?,";
            
            cmd = con.prepareStatement(sql);
            cmd.setString(1, p.getNome());
            cmd.setFloat(2, p.getPeso());
            cmd.setFloat(3, p.getAltura());
            cmd.setInt(4, p.getId());
            
            if (cmd.executeUpdate() > 0){
                return p.getId();
            }
            else{
                return -1;
            }
        }
        catch (SQLException e){
            System.out.println("ERRO:" + e.getMessage());
            return -1;
        }
        finally{
            Conexao.Desconectar(con);
        }
    }
    
}
